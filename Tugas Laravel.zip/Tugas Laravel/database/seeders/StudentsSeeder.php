<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StudentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Mengisi data awal pada tabel students
        DB::table('students')->insert([
            [
                'name' => 'Mahasiswa 1',
                'age' => 20,
                'classroom' => 'Kelas 1',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Mahasiswa 2',
                'age' => 21,
                'classroom' => 'Kelas 2',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Mahasiswa 3',
                'age' => 22,
                'classroom' => 'Kelas 3',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Mahasiswa 4',
                'age' => 23,
                'classroom' => 'Kelas 4',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Mahasiswa 5',
                'age' => 24,
                'classroom' => 'Kelas 5',
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }

    
}

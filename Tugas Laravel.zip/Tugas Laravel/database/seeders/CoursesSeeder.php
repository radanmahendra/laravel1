<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CoursesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('courses')->insert([
            ['course_name' => 'PTIK','description' => 'Deskripsi mata kuliah PTIK'],
            ['course_name' => 'MediaTIK','description' => 'Deskripsi mata kuliah PTIK'],
            ['course_name' => 'ALPRO','description' => 'Deskripsi mata kuliah PTIK'],
                       
        ]);
    
        // Tambahkan data mata kuliah lainnya sesuai kebutuhan
    }
    
}
